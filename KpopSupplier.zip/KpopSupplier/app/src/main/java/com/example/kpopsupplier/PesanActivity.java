package com.example.kpopsupplier;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PesanActivity extends AppCompatActivity {
    TextView tvhargaalbum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesan);
        tvhargaalbum=findViewById(R.id.tvHagra);
        tvhargaalbum.setText(getIntent().getStringExtra("harga"));
    }
}