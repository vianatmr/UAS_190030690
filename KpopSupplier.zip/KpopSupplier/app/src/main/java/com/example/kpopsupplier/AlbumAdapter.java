package com.example.kpopsupplier;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.AlbumViewHolder> {
    private Context context;
    private ArrayList<Album> albums;

    public AlbumAdapter(Context acontext, ArrayList<Album> albumkpop)
    {
        context=acontext;
        albums=albumkpop;

    }

    @NonNull
    @Override
    public AlbumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_menu,parent,false);
        return new AlbumViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AlbumViewHolder holder, int position) {
        Album albumbaru = albums.get(position);
        String gambarbaru = albumbaru.getGambar();
        String harga = albumbaru.getHarga();
        String judul = albumbaru.getJudul();
        String deskripsi = albumbaru.getDeskripsi();
        String artis = albumbaru.getArtis();

        holder.tvnamadata.setText(judul);
        holder.tvhargadata.setText(harga);
        holder.tvdeskripsi.setText(deskripsi);
        holder.tvartis.setText(artis);
        holder.btPesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(v.getContext(),PesanActivity.class);
                pindah.putExtra("harga",albumbaru.getHarga());
                v.getContext().startActivity(pindah);
            }
        });
        Glide
                .with(context)
                .load(gambarbaru)
                .centerCrop()
                .into(holder.imdata);



    }

    @Override
    public int getItemCount() {
        return albums.size();
    }

    public class AlbumViewHolder extends RecyclerView.ViewHolder {
        public ImageView imdata;
        public TextView tvhargadata;
        public TextView tvnamadata;
        public TextView tvdeskripsi;
        public TextView tvartis;
        public Button btPesan;

        public AlbumViewHolder(@NonNull View itemView) {
            super(itemView);
            imdata = itemView.findViewById(R.id.img_album);
            tvhargadata = itemView.findViewById(R.id.tv_harga);
            tvnamadata = itemView.findViewById(R.id.tv_nama);
            tvdeskripsi = itemView.findViewById(R.id.tv_deskripsi);
            tvartis = itemView.findViewById(R.id.tv_artis);
            btPesan = itemView.findViewById(R.id.btn_pesan);
        }
    }
}
