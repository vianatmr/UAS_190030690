package com.example.kpopsupplier;

public class Album {
    private String judul;
    private String harga;
    private String gambar;
    private String deskripsi;
    private String artis;

    public Album(String datajudul, String dataharga, String datagambar, String datadeskripsi,
                 String dataartis) {
        judul = datajudul;
        harga = dataharga;
        gambar = datagambar;
        deskripsi = datadeskripsi;
        artis = dataartis;
    }

    public String getJudul() {
        return judul;
    }

    public String getHarga() {
        return harga;
    }

    public String getGambar() {
        return gambar;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getArtis() {
        return artis;
    }
}

